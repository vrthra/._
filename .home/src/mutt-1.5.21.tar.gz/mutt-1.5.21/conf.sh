./configure --enable-pop --enable-imap --enable-smtp --enable-hcache --with-regex --with-gnutls --with-ssl --with-sasl
